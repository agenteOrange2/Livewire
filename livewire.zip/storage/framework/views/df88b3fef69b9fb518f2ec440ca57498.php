<div <?php echo e($attributes->merge(['class' => ' flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gray-100'])); ?>>
    
    <div class="w-full sm:max-w-4xl bg-white shadow-md overflow-hidden sm:rounded-lg">

        <div class="bg-gray-50 py-3">
            <h2 class="text-3xl text-center text-gray-600"><?php echo e($title); ?></h2>
        </div>
        <div class="px-6 py-4">
            <?php echo e($slot); ?>

        </div>
        
    </div>

</div><?php /**PATH D:\xampp\htdocs\Laravel\livewire\resources\views/components/card.blade.php ENDPATH**/ ?>