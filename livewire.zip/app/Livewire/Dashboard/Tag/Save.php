<?php

namespace App\Livewire\Dashboard\Tag;

use Livewire\Component;

class Save extends Component
{
    public function render()
    {
        return view('livewire.dashboard.tag.save');
    }
}
